(function() {

  return { // the entire app goes inside this returh block!
    
    // listen for API events such as the start of our app, when bits of it get clicked on or when AJAX requests complete
    events: {
      'app.activated':'initialize', // this event is run once when the app loads and calls the 'initialize' function
      'ticket.type.changed':'initialize', // API event fired when the ticket type changes (eg a ticket is marked as an Incident or a Question is changed to a Problem)
      'click .demoapp_button':'button_clicked',
      'change #tickettypeset':'newtickettype'
    },

    initialize: function() { // function called when we load or the ticket type is modified
          var self = this;
          var templateData = {
            type_label:        self.getTypeLabel(),
            type_is_visible:   self.isTypeVisible(),
            type_is_required:  self.isTypeRequired(),
            type_options:      self.getTypeOptions(),
            status_is_visible: self.getStatusVisible(),
            status_options:    self.getStatusOptions()
          };

      self.switchTo('main', templateData);
    },

        /* GETTERS */

    getTypeLabel: function() {
      return this.ticketFields("type").label();
    },

    isTypeVisible: function() {
      return this.ticketFields("type").isVisible() ? 'Yes' : 'No';
    },

    isTypeDisabled: function() {
      // To be implemented
    },

    isTypeRequired: function() {
      return this.ticketFields("type").isRequired() ? 'Yes' : 'No';
    },

    getTypeOptions: function() {
      var options = this.ticketFields("type").options(),
          labels  = [];

      options.forEach(function(element) {
          labels.push(element.label());
        }
      );

      return labels;
    },

    getStatusVisible: function() {
      return this.ticketFields("status").isVisible() ? 'Yes' : 'No';
    },

    getStatusDisabled: function() {
      // To be implemented
    },

    getStatusOptions: function() {
      var options = this.ticketFields("status").options(),
          labels  = [];

      options.forEach(function(element) {
          labels.push(element.label());
        }
      );

      return labels;
    },

    /* UI Events */
    button_clicked: function(data) {
      var clicked = data.currentTarget.id;
      this.$('.active').toggleClass('active');
      this.$('#'+clicked).toggleClass('active');
      switch (clicked)
      {
        case 'ticket':
        this.switchTo('ticket', {
          ticketType: this.ticket().type(),
          ticketSubject: this.ticket().subject(),
          ticketTypes: ['Question', 'Problem', 'Incident', 'Task']
        });
        break;
        case 'user':
        break;
        case 'account':
        break;
        default:
        break;
      }
      },
    newtickettype: function(data) {
      var newtype = data.currentTarget.value;
      console.log('new type: ' + newtype);
      this.ticket().type(newtype.toLowerCase());

    }
  };

}());
