:warning: *Use of this software is subject to important terms and conditions as set forth in the License file* :warning:

# External RESTful API sample without auth

This sample app displays [...something] on the User Sidebar. It is designed to show you how to use external RESTful APIs without authentication invovled.

### The following information is displayed:

[...something]

Please submit bug reports to [Zendesk](https://support.zendesk.com/requests/new). Pull requests are welcome.

### Screenshot(s):

